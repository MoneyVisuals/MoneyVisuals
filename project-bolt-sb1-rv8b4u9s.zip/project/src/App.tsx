import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from 'react';
import {
  ArrowRight, BadgeCheck, BookOpen, Boxes, Check, CheckCircle2, ChevronRight, CircleHelp,
  Clipboard, Clock3, CreditCard, Crown, ExternalLink, Eye, FileArchive, Gift, History, KeyRound,
  LayoutDashboard, LockKeyhole, LogIn, LogOut, Menu, Package, Pencil, Plus, Trash2, Upload,
  ShieldCheck, Sparkles, Tag, UserRound, Users, X, Zap
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

type Plan = { id: string; slug: string; name: string; duration_days: number; price: number; description: string; accent: string; is_featured: boolean; is_active: boolean };
type Profile = { id: string; username: string; email: string; role: 'user' | 'admin'; hwid: string | null; created_at: string };
type Order = { id: string; plan_name: string; price: number; status: string; receipt_path: string | null; asset_id?: string | null; created_at: string };
type Asset = { id: string; name: string; version: string; file_path: string; file_size: number; is_active: boolean; created_at: string };
type Entitlement = { id: string; plan_name: string; status: string; starts_at: string; expires_at: string | null; asset: Asset | null };
type BonusClaim = { id: string; reward_type: string; reward_value: string; claimed_on: string; created_at: string };
type AuthMode = 'login' | 'register';
type View = 'home' | 'plans' | 'account' | 'admin' | 'help';

const fallbackPlans: Plan[] = [
  { id: 'starter', slug: 'starter-30', name: 'Starter Visual', duration_days: 30, price: 12000, description: 'Asosiy vizual paket va tezkor aktivatsiya.', accent: 'cyan', is_featured: false, is_active: true },
  { id: 'pro', slug: 'pro-90', name: 'Pro Visual', duration_days: 90, price: 30000, description: 'Uzoq muddatli foydalanish va premium effektlar.', accent: 'emerald', is_featured: true, is_active: true },
  { id: 'lifetime', slug: 'forever', name: 'Lifetime Visual', duration_days: 3650, price: 50000, description: 'Bir marta to‘lang, uzoq muddat foydalaning.', accent: 'gold', is_featured: false, is_active: true },
];
const backgroundImage = 'https://images.pexels.com/photos/9072216/pexels-photo-9072216.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

function formatPrice(value: number) { return new Intl.NumberFormat('uz-UZ').format(value); }
function friendlyError(message: string) { if (message.toLowerCase().includes('invalid login')) return 'Login yoki parol noto‘g‘ri.'; if (message.toLowerCase().includes('already registered')) return 'Bu email allaqachon ro‘yxatdan o‘tgan.'; return 'Amalni bajarib bo‘lmadi. Qaytadan urinib ko‘ring.'; }

function App() {
  const [session, setSession] = useState<{ user: { id: string; email?: string } } | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [plans, setPlans] = useState<Plan[]>(fallbackPlans);
  const [orders, setOrders] = useState<Order[]>([]);
  const [entitlements, setEntitlements] = useState<Entitlement[]>([]);
  const [bonusClaims, setBonusClaims] = useState<BonusClaim[]>([]);
  const [view, setView] = useState<View>('home');
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => { if (mounted) { setSession(data.session); setLoading(false); } });
    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => { mounted = false; data.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!session) { setProfile(null); setOrders([]); setEntitlements([]); setBonusClaims([]); return; }
    void loadUserData(session.user.id);
  }, [session]);

  useEffect(() => {
    void loadPlans();
  }, []);

  async function loadPlans() {
    const { data } = await supabase.from('plans').select('*').eq('is_active', true).order('price');
    if (data?.length) setPlans(data as Plan[]);
  }

  async function loadUserData(userId: string) {
    const [{ data: profileData }, { data: orderData }, { data: entitlementData }, { data: bonusData }] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
      supabase.from('orders').select('id, plan_name, price, status, receipt_path, asset_id, created_at').eq('user_id', userId).order('created_at', { ascending: false }),
      supabase.from('user_entitlements').select('id, plan_name, status, starts_at, expires_at, asset:mod_assets(*)').eq('user_id', userId).order('created_at', { ascending: false }),
      supabase.from('daily_bonus_claims').select('id, reward_type, reward_value, claimed_on, created_at').eq('user_id', userId).order('created_at', { ascending: false }),
    ]);
    if (profileData) setProfile(profileData as Profile);
    if (orderData) setOrders(orderData as Order[]);
    if (entitlementData) setEntitlements((entitlementData as Array<Entitlement & { asset: Asset | Asset[] | null }>).map((item) => ({ ...item, asset: Array.isArray(item.asset) ? item.asset[0] || null : item.asset })));
    if (bonusData) setBonusClaims(bonusData as BonusClaim[]);
  }

  function navigate(nextView: View) { setView(nextView); setMenuOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }); }

  async function signOut() { await supabase.auth.signOut(); setView('home'); setNotice('Hisobdan chiqildi.'); }

  async function createOrder(plan: Plan, receipt: File, promoCode: string) {
    if (!session) { setAuthMode('login'); setAuthOpen(true); return; }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(plan.id)) { setNotice('Tarif ma’lumotlari yangilanmoqda. Qaytadan urinib ko‘ring.'); return; }
    const safeName = receipt.name.toLowerCase().replace(/[^a-z0-9.]+/g, '-');
    const receiptPath = `${session.user.id}/${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from('payment-receipts').upload(receiptPath, receipt, { contentType: receipt.type, upsert: false });
    if (uploadError) { setNotice('Chekni yuklab bo‘lmadi. Qaytadan urinib ko‘ring.'); return; }
    const { data, error } = await supabase.rpc('create_order_with_promo', { p_plan_id: plan.id, p_receipt_path: receiptPath, p_promo_code: promoCode.trim() || null });
    if (error || !data) { await supabase.storage.from('payment-receipts').remove([receiptPath]); setNotice(error?.message?.toLowerCase().includes('promo') ? 'Promo kod yaroqsiz yoki limiti tugagan.' : 'Buyurtma yaratilmadi. Qaytadan urinib ko‘ring.'); return; }
    await loadUserData(session.user.id);
    setSelectedPlan(null);
    setView('account');
    setNotice(`To‘lov cheki yuborildi. Yakuniy summa: ${formatPrice(data.final_price)} so‘m.`);
  }

  if (loading) return <div className="loading-screen"><div className="loader-ring" /><span>MoneyVisuals yuklanmoqda</span></div>;

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <button className="brand" onClick={() => navigate('home')} aria-label="MoneyVisuals bosh sahifa"><span className="brand-mark"><Zap size={19} fill="currentColor" /></span><span>Money<span>Visuals</span></span></button>
        <nav className={menuOpen ? 'nav-links is-open' : 'nav-links'}>
          <button className={view === 'home' ? 'nav-link active' : 'nav-link'} onClick={() => navigate('home')}>Bosh sahifa</button>
          <button className={view === 'plans' ? 'nav-link active' : 'nav-link'} onClick={() => navigate('plans')}>Tariflar</button>
          <button className={view === 'help' ? 'nav-link active' : 'nav-link'} onClick={() => navigate('help')}>Yordam</button>
        </nav>
        <div className="top-actions">
          {session ? <>
            {profile?.role === 'admin' && <button className="icon-button" onClick={() => navigate('admin')} title="Admin panel"><ShieldCheck size={18} /></button>}
            <button className="profile-pill" onClick={() => navigate('account')}><span className="avatar">{profile?.username?.slice(0, 1).toUpperCase() || 'U'}</span><span>{profile?.username || 'Hisobim'}</span></button>
          </> : <button className="button button-small button-outline" onClick={() => { setAuthMode('login'); setAuthOpen(true); }}><LogIn size={16} /> Kirish</button>}
          <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        </div>
      </header>

      {notice && <div className="toast"><BadgeCheck size={17} /> {notice}<button onClick={() => setNotice('')}><X size={14} /></button></div>}

      <main>
        {view === 'home' && <Home plans={plans} onPlans={() => navigate('plans')} onSelect={(plan) => setSelectedPlan(plan)} />}
        {view === 'plans' && <Plans plans={plans} onSelect={(plan) => setSelectedPlan(plan)} />}
        {view === 'account' && <Account profile={profile} orders={orders} entitlements={entitlements} bonusClaims={bonusClaims} onRedeemed={() => profile && loadUserData(profile.id)} onSignOut={signOut} />}
        {view === 'admin' && <Admin profile={profile} plans={plans} />}
        {view === 'help' && <Help />}
      </main>

      <footer className="footer"><div className="footer-main"><div><div className="brand footer-brand"><span className="brand-mark"><Zap size={18} fill="currentColor" /></span><span>Money<span>Visuals</span></span></div><p>Minecraft uchun tiniq, tezkor va chiroyli visual tajriba.</p></div><div><h4>Tezkor menyu</h4><button onClick={() => navigate('home')}>Bosh sahifa</button><button onClick={() => navigate('plans')}>Mahsulotlar</button><button onClick={() => navigate('help')}>Yordam</button></div><div><h4>Qo‘llab-quvvatlash</h4><p>Discord: <strong>MoneySupport</strong></p><p>Har kuni 24/7 yordam</p></div></div><div className="footer-bottom">© 2026 MoneyVisuals <span>•</span> Xavfsiz qo‘lda aktivatsiya</div></footer>

      {selectedPlan && <Checkout plan={selectedPlan} onClose={() => setSelectedPlan(null)} onConfirm={(receipt, promoCode) => createOrder(selectedPlan, receipt, promoCode)} />}
      {authOpen && <AuthModal mode={authMode} onModeChange={setAuthMode} onClose={() => setAuthOpen(false)} />}
    </div>
  );
}

function Home({ plans, onPlans, onSelect }: { plans: Plan[]; onPlans: () => void; onSelect: (plan: Plan) => void }) {
  return <>
    <section className="hero page-width"><div className="hero-copy"><div className="eyebrow"><span className="live-dot" /> PREMIUM MINECRAFT VISUALS</div><h1>O‘yiningizni <span>yoriting.</span><br />Uslubingizni toping.</h1><p className="hero-text">MoneyVisuals bilan Minecraft tajribangizni keyingi bosqichga olib chiqing. Silliq ishlash, tiniq ko‘rinish va har bir detalda premium kayfiyat.</p><div className="hero-actions"><button className="button button-primary" onClick={onPlans}>Tariflarni ko‘rish <ArrowRight size={18} /></button><button className="button button-ghost" onClick={() => document.getElementById('why')?.scrollIntoView({ behavior: 'smooth' })}>Batafsil <ChevronRight size={17} /></button></div><div className="hero-proof"><div className="proof-avatars"><span>MV</span><span>UZ</span><span>+</span></div><div><strong>1,200+</strong><small>mamnun foydalanuvchi</small></div><div className="proof-line" /><div><strong>24/7</strong><small>qo‘llab-quvvatlash</small></div></div></div><div className="hero-visual"><div className="hero-image-wrap"><img src={backgroundImage} alt="Neon gaming setup" /><div className="image-overlay" /><div className="floating-stat stat-top"><span className="stat-icon cyan"><Zap size={16} fill="currentColor" /></span><div><strong>+42 FPS</strong><small>Barqaror ishlash</small></div></div><div className="floating-stat stat-bottom"><span className="stat-icon emerald"><Sparkles size={16} /></span><div><strong>Visual ON</strong><small>Premium effektlar faol</small></div><span className="signal-bars"><i /><i /><i /><i /></span></div><div className="scan-line" /></div></div></section>
    <section className="metrics page-width"><div><strong>0.1ms</strong><span>tezkor javob</span></div><div><strong>4K</strong><span>tiniq tasvir</span></div><div><strong>100%</strong><span>ishonchli aktivatsiya</span></div><div><strong>24/7</strong><span>yordam xizmati</span></div></section>
    <section id="why" className="section page-width"><div className="section-heading"><div><div className="eyebrow">NIMA UCHUN BIZ?</div><h2>Oddiydan ko‘ra <span>yaxshiroq.</span></h2></div><p>Har bir paket o‘yin davomida silliq ishlash va ko‘zga yoqimli ko‘rinish uchun tayyorlangan.</p></div><div className="feature-grid"><Feature icon={<Zap />} title="Ultra tez" text="FPS tushishlarisiz silliq va barqaror visual tajriba." /><Feature icon={<Eye />} title="Tiniq ko‘rinish" text="Har bir blok, rang va detal yanada jonli ko‘rinsin." /><Feature icon={<ShieldCheck />} title="Xavfsiz aktivatsiya" text="Hisobingiz va aktivatsiyangiz himoyalangan holatda." /></div></section>
    <section className="section section-plans page-width"><div className="section-heading"><div><div className="eyebrow">ENG OMMABOP</div><h2>O‘zingizga mos <span>paket.</span></h2></div><button className="text-button" onClick={onPlans}>Barcha tariflar <ArrowRight size={16} /></button></div><div className="plan-grid">{plans.map((plan) => <PlanCard key={plan.id} plan={plan} onSelect={onSelect} />)}</div></section>
  </>;
}

function Feature({ icon, title, text }: { icon: JSX.Element; title: string; text: string }) { return <div className="feature-card glass-card"><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{text}</p><span className="feature-arrow"><ArrowRight size={16} /></span></div>; }
function PlanCard({ plan, onSelect }: { plan: Plan; onSelect: (plan: Plan) => void }) { return <article className={`plan-card glass-card ${plan.is_featured ? 'featured' : ''}`}><div className="plan-top"><span className={`plan-badge ${plan.accent}`}>{plan.is_featured ? <><Crown size={13} /> ENG KO‘P TANLANGAN</> : <><Sparkles size={13} /> PREMIUM</>}</span><span className="plan-duration"><Clock3 size={14} /> {plan.duration_days > 1000 ? 'Lifetime' : `${plan.duration_days} kun`}</span></div><h3>{plan.name}</h3><p>{plan.description}</p><div className="plan-price"><strong>{formatPrice(plan.price)}</strong><span>so‘m</span></div><div className="plan-list"><span><Check size={15} /> Instant aktivatsiya</span><span><Check size={15} /> HWID himoya</span><span><Check size={15} /> 24/7 yordam</span></div><button className={plan.is_featured ? 'button button-primary full' : 'button button-outline full'} onClick={() => onSelect(plan)}>Sotib olish <ArrowRight size={16} /></button></article>; }

function Plans({ plans, onSelect }: { plans: Plan[]; onSelect: (plan: Plan) => void }) { return <section className="inner-page page-width"><div className="inner-hero"><div className="eyebrow">MONEYVISUALS STORE</div><h1>Premium tariflar</h1><p>Bir marta tanlang — o‘yin davomida farqni his qiling.</p></div><div className="plan-grid expanded">{plans.map((plan) => <PlanCard key={plan.id} plan={plan} onSelect={onSelect} />)}</div><div className="trust-strip glass-card"><ShieldCheck size={22} /><div><strong>To‘lovdan so‘ng aktivatsiya</strong><span>Buyurtma tasdiqlangach, visualingiz hisobingizga biriktiriladi.</span></div><BadgeCheck size={21} /></div></section>; }

function AuthModal({ mode, onModeChange, onClose }: { mode: AuthMode; onModeChange: (mode: AuthMode) => void; onClose: () => void }) { const [username, setUsername] = useState(''); const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [repeat, setRepeat] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent) { event.preventDefault(); setError(''); if (mode === 'register' && password !== repeat) { setError('Parollar mos kelmadi.'); return; } setBusy(true); const result = mode === 'register' ? await supabase.auth.signUp({ email, password, options: { data: { username } } }) : await supabase.auth.signInWithPassword({ email, password }); setBusy(false); if (result.error) { setError(friendlyError(result.error.message)); return; } onClose(); }
  return <div className="modal-backdrop"><div className="auth-modal glass-card"><button className="modal-close" onClick={onClose}><X size={19} /></button><div className="auth-logo"><span className="brand-mark"><Zap size={18} fill="currentColor" /></span></div><div className="auth-title"><div className="eyebrow">MONEYVISUALS ACCOUNT</div><h2>{mode === 'login' ? 'Xush kelibsiz.' : 'Hisob yarating.'}</h2><p>{mode === 'login' ? 'Davom etish uchun hisobingizga kiring.' : 'Premium visual olamiga bir qadam qoldi.'}</p></div><form onSubmit={submit}>{mode === 'register' && <label>Username<input required value={username} onChange={(event) => setUsername(event.target.value)} placeholder="username" /></label>}<label>Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></label><label>Parol<input required minLength={6} type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="••••••••" /></label>{mode === 'register' && <label>Parolni takrorlang<input required minLength={6} type="password" value={repeat} onChange={(event) => setRepeat(event.target.value)} placeholder="••••••••" /></label>}{error && <div className="form-error">{error}</div>}<button className="button button-primary full" disabled={busy}>{busy ? 'Kutilmoqda...' : mode === 'login' ? <><LogIn size={17} /> Kirish</> : <><UserRound size={17} /> Ro‘yxatdan o‘tish</>}</button></form><p className="auth-switch">{mode === 'login' ? 'Hisobingiz yo‘qmi?' : 'Hisobingiz bormi?'} <button onClick={() => { onModeChange(mode === 'login' ? 'register' : 'login'); setError(''); }}>{mode === 'login' ? 'Ro‘yxatdan o‘ting' : 'Kirish'}</button></p></div></div>; }

function Checkout({ plan, onClose, onConfirm }: { plan: Plan; onClose: () => void; onConfirm: (receipt: File, promoCode: string) => void }) { const [copied, setCopied] = useState(false); const [receipt, setReceipt] = useState<File | null>(null); const [promoCode, setPromoCode] = useState(''); const [error, setError] = useState(''); function copyCard() { void navigator.clipboard?.writeText('9860 1201 6745 4723'); setCopied(true); setTimeout(() => setCopied(false), 1800); } function chooseReceipt(event: ChangeEvent<HTMLInputElement>) { const file = event.target.files?.[0] || null; if (!file) return; if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) { setReceipt(null); setError('Faqat JPG, PNG yoki WEBP rasm, 5 MB gacha.'); return; } setReceipt(file); setError(''); } function submitPayment() { if (!receipt) { setError('Avval to‘lov chekini yuklang.'); return; } onConfirm(receipt, promoCode); } return <div className="modal-backdrop"><div className="checkout-modal glass-card"><button className="modal-close" onClick={onClose}><X size={19} /></button><div className="checkout-header"><div><div className="eyebrow">XAVFSIZ BUYURTMA</div><h2>To‘lovni yakunlang</h2></div><span className="checkout-lock"><LockKeyhole size={16} /> SSL</span></div><div className="checkout-plan"><div className="plan-mini-icon"><Package size={19} /></div><div><strong>{plan.name}</strong><span>{plan.duration_days > 1000 ? 'Lifetime' : `${plan.duration_days} kunlik`} visual</span></div><b>{formatPrice(plan.price)} so‘m</b></div><div className="payment-label"><span>To‘lov usuli</span><span className="accepted">VISA <b>UZCARD</b></span></div><div className="bank-card"><div className="card-top"><span>MoneyVisuals</span><CreditCard size={25} /></div><div className="card-number">9860 1201 6745 4723</div><div className="card-bottom"><span><small>KARTA EGASI</small><b>MoneyVisuals</b></span><span><small>TIZIM</small><b>UZCARD</b></span></div></div><button className="copy-card" onClick={copyCard}><Clipboard size={15} /> {copied ? 'Nusxalandi' : 'Karta raqamini nusxalash'}</button><div className="promo-input"><label htmlFor="checkout-promo">Promo code</label><div><Tag size={16} /><input id="checkout-promo" value={promoCode} onChange={(event) => setPromoCode(event.target.value.toUpperCase())} placeholder="PROMO2026 (ixtiyoriy)" maxLength={32} /></div><small>Chegirma faqat faol va limiti tugamagan kodlarga beriladi.</small></div><div className="receipt-upload"><label htmlFor="receipt-file">Chek tashlash uchun</label><input id="receipt-file" type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseReceipt} /><span>{receipt ? receipt.name : 'JPG, PNG yoki WEBP — 5 MB gacha'}</span></div>{error && <p className="form-error">{error}</p>}<p className="payment-note">To‘lovni amalga oshirgach, chek rasmini yuklang. Promo kod serverda tekshiriladi, admin tasdiqlaganidan so‘ng visual hisobingizga biriktiriladi.</p><button className="button button-primary full" onClick={submitPayment}><Check size={17} /> To‘lov qildim</button></div></div>; }

function Account({ profile, orders, entitlements, bonusClaims, onRedeemed, onSignOut }: { profile: Profile | null; orders: Order[]; entitlements: Entitlement[]; bonusClaims: BonusClaim[]; onRedeemed: () => void; onSignOut: () => void }) { const [key, setKey] = useState(''); const [message, setMessage] = useState(''); const [busy, setBusy] = useState(false); async function redeem(event: FormEvent) { event.preventDefault(); setBusy(true); setMessage(''); const { error } = await supabase.rpc('redeem_activation_key', { p_key: key }); setBusy(false); if (error) { setMessage('Kalit yaroqsiz yoki avval ishlatilgan.'); return; } setKey(''); setMessage('Kalit muvaffaqiyatli faollashtirildi.'); onRedeemed(); } return <section className="inner-page page-width account-page"><AccountExtras entitlements={entitlements} bonusClaims={bonusClaims} onClaimed={onRedeemed} /><div className="account-head"><div><div className="eyebrow">SHAXSIY KABINET</div><h1>Salom, <span>{profile?.username || 'foydalanuvchi'}</span></h1><p>Hisobingiz, buyurtmalaringiz va aktivatsiyalaringiz bir joyda.</p></div><div className="account-tools"><div className="account-avatar">{profile?.username?.slice(0, 1).toUpperCase() || 'U'}</div><button className="button button-ghost" onClick={onSignOut}><LogOut size={15} /> Chiqish</button></div></div><div className="account-grid"><div className="account-main glass-card"><div className="card-heading"><div><span className="small-label">PROFIL MA’LUMOTLARI</span><h3>Hisob ma’lumotlari</h3></div><UserRound size={20} /></div><div className="profile-details"><div><small>Username</small><strong>{profile?.username}</strong></div><div><small>Email</small><strong>{profile?.email}</strong></div><div><small>Holat</small><strong className="status"><span /> Faol</strong></div></div><div className="account-divider" /><div className="card-heading"><div><span className="small-label">KALIT AKTIVATSIYASI</span><h3>Visual kalitingiz bormi?</h3></div><KeyRound size={20} /></div><form className="key-form" onSubmit={redeem}><input value={key} onChange={(event) => setKey(event.target.value)} placeholder="MV-XXXX-XXXX-XXXX" required /><button className="button button-primary" disabled={busy}>{busy ? 'Tekshirilmoqda' : 'Faollashtirish'} <ArrowRight size={16} /></button></form>{message && <p className="inline-message">{message}</p>}</div><aside className="account-side"><div className="balance-card glass-card"><div className="balance-top"><span>HISOB HOLATI</span><ShieldCheck size={17} /></div><strong>Premium <span>account</span></strong><p>HWID himoyasi yoqilgan</p><div className="balance-line"><i /></div></div><div className="orders-card glass-card"><div className="card-heading"><h3>Buyurtmalar</h3><Package size={18} /></div>{orders.length === 0 ? <div className="empty-state"><Boxes size={26} /><span>Hali buyurtma yo‘q</span></div> : orders.slice(0, 4).map((order) => <div className="order-row" key={order.id}><span className="order-icon"><Tag size={15} /></span><div><strong>{order.plan_name}</strong><small>{new Date(order.created_at).toLocaleDateString('uz-UZ')}</small></div><b className={order.status === 'paid' ? 'paid' : ''}>{order.status === 'paid' ? 'Faol' : 'Kutilmoqda'}</b></div>)}</div></aside></div></section>; }

async function downloadAsset(filePath: string) { const { data, error } = await supabase.storage.from('mod-files').createSignedUrl(filePath, 300); if (!error && data?.signedUrl) window.open(data.signedUrl, '_blank', 'noopener,noreferrer'); }

function AccountExtras({ entitlements, bonusClaims, onClaimed }: { entitlements: Entitlement[]; bonusClaims: BonusClaim[]; onClaimed: () => void }) { return <div className="account-extras"><div className="bonus-panel glass-card"><DailyBonus claims={bonusClaims} onClaimed={onClaimed} /></div><div className="history-card glass-card"><div className="card-heading"><div><span className="small-label">SOTIB OLINGAN VISUAL</span><h3>Mening modlarim</h3></div><Package size={18} /></div>{entitlements.length === 0 ? <div className="empty-state"><Package size={25} /><span>Hali aktiv visual yo‘q</span></div> : entitlements.map((item) => <div className="entitlement-row" key={item.id}><div className="plan-mini-icon"><Sparkles size={16} /></div><div><strong>{item.asset?.name || item.plan_name}</strong><small>{item.asset?.version ? `v${item.asset.version}` : 'Mod tayyor'}</small></div><span>{item.status === 'active' ? 'Faol' : item.status}</span><button className="button button-outline" onClick={() => item.asset && void downloadAsset(item.asset.file_path)}><ExternalLink size={15} /> Yuklab olish</button></div>)}</div></div>; }

function DailyBonus({ claims, onClaimed }: { claims: BonusClaim[]; onClaimed: () => void }) { const [busy, setBusy] = useState(false); const [message, setMessage] = useState(''); const claimedToday = claims.some((claim) => claim.claimed_on === new Date().toISOString().slice(0, 10)); async function claim() { setBusy(true); setMessage(''); const { data, error } = await supabase.rpc('claim_daily_bonus'); setBusy(false); if (error) { setMessage('Bugungi bonus allaqachon olingan.'); return; } setMessage(`Tabriklaymiz: ${data.reward_value}`); onClaimed(); } return <div className="daily-bonus"><div className="card-heading"><div><span className="small-label">BONUS CENTER</span><h3>Kunlik bonus</h3></div><Gift size={19} /></div><p>Har kuni bitta bonus kartasini oching. Bonuslar tarixda saqlanadi.</p><div className="bonus-cards">{['promo', 'balance', 'cosmetic'].map((type, index) => <button className={`bonus-card ${claimedToday ? 'claimed' : ''}`} key={type} onClick={() => void claim()} disabled={busy || claimedToday}><span>{claimedToday ? '✓' : `0${index + 1}`}</span><strong>{type === 'promo' ? 'Promo' : type === 'balance' ? 'Balans' : 'Cosmetic'}</strong><small>{claimedToday ? 'Ochildi' : 'Ochish'}</small></button>)}</div>{message && <p className="inline-message">{message}</p>}<div className="bonus-history"><span>Oxirgi bonuslar</span>{claims.slice(0, 4).map((claim) => <small key={claim.id}>{claim.claimed_on} — {claim.reward_value}</small>)}</div></div>; }

type AdminOrder = Order & { user_id: string; profile?: Profile | null };
type PromoCode = { id: string; code: string; discount_percent: number; uses: number; max_uses: number };
type ActivationKey = { id: string; key_value: string; plan_name: string; duration_days: number; used_at: string | null };

function Admin({ profile, plans }: { profile: Profile | null; plans: Plan[] }) {
  const [tab, setTab] = useState('overview');
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [codes, setCodes] = useState<PromoCode[]>([]);
  const [keys, setKeys] = useState<ActivationKey[]>([]);
  const [bonusHistory, setBonusHistory] = useState<BonusClaim[]>([]);
  const [newCode, setNewCode] = useState('');
  const [discount, setDiscount] = useState('10');
  const [keyPlan, setKeyPlan] = useState('30 kunlik Visual');
  const [keyDays, setKeyDays] = useState('30');
  const [assetName, setAssetName] = useState('MoneyVisuals Mod');
  const [assetVersion, setAssetVersion] = useState('1.0.0');
  const [selectedAsset, setSelectedAsset] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const loadData = useCallback(async () => {
    const [{ data: orderData }, { data: userData }, { data: assetData }, { data: codeData }, { data: keyData }, { data: bonusData }] = await Promise.all([
      supabase.from('orders').select('id, user_id, plan_name, price, status, receipt_path, asset_id, created_at').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('mod_assets').select('*').order('created_at', { ascending: false }),
      supabase.from('promo_codes').select('id, code, discount_percent, uses, max_uses').order('created_at', { ascending: false }),
      supabase.from('activation_keys').select('id, key_value, plan_name, duration_days, used_at').order('created_at', { ascending: false }),
      supabase.from('daily_bonus_claims').select('id, user_id, reward_type, reward_value, claimed_on, created_at').order('created_at', { ascending: false }),
    ]);
    const profileMap = new Map((userData as Profile[] || []).map((user) => [user.id, user]));
    if (orderData) setOrders((orderData as AdminOrder[]).map((order) => ({ ...order, profile: profileMap.get(order.user_id) })));
    if (userData) setUsers(userData as Profile[]);
    if (assetData) setAssets(assetData as Asset[]);
    if (codeData) setCodes(codeData as PromoCode[]);
    if (keyData) setKeys(keyData as ActivationKey[]);
    if (bonusData) setBonusHistory(bonusData as BonusClaim[]);
  }, []);

  useEffect(() => { if (profile?.role === 'admin') void loadData(); }, [profile, loadData]);

  async function approveOrder(orderId: string) {
    if (!selectedAsset) { setMessage('Avval mod faylini tanlang.'); return; }
    setBusy(true);
    const { error } = await supabase.rpc('approve_order', { p_order_id: orderId, p_asset_id: selectedAsset });
    setBusy(false);
    setMessage(error ? 'Buyurtmani tasdiqlab bo‘lmadi.' : 'Buyurtma tasdiqlandi va mod xaridorga biriktirildi.');
    if (!error) void loadData();
  }

  async function openReceipt(path: string | null) {
    if (!path) return;
    const { data, error } = await supabase.storage.from('payment-receipts').createSignedUrl(path, 300);
    if (!error && data?.signedUrl) window.open(data.signedUrl, '_blank', 'noopener,noreferrer');
  }

  async function uploadMod(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) { setMessage('Mod fayli 50 MB dan kichik bo‘lishi kerak.'); return; }
    setBusy(true);
    const safeName = file.name.toLowerCase().replace(/[^a-z0-9.]+/g, '-');
    const filePath = `admin/${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage.from('mod-files').upload(filePath, file, { contentType: file.type || 'application/octet-stream', upsert: false });
    if (uploadError) { setBusy(false); setMessage('Mod faylini yuklab bo‘lmadi.'); return; }
    const { error } = await supabase.from('mod_assets').insert({ name: assetName, version: assetVersion, file_path: filePath, file_size: file.size });
    setBusy(false);
    if (error) { await supabase.storage.from('mod-files').remove([filePath]); setMessage('Mod ma’lumotini saqlab bo‘lmadi.'); return; }
    setMessage('Mod fayli tayyor. Endi buyurtmani shu modga biriktiring.');
    void loadData();
  }

  async function addCode(event: FormEvent) { event.preventDefault(); const { error } = await supabase.from('promo_codes').insert({ code: newCode.toUpperCase(), discount_percent: Number(discount) }); setMessage(error ? 'Promo kod qo‘shilmadi.' : 'Promo kod yaratildi.'); if (!error) { setNewCode(''); void loadData(); } }
  async function deleteCode(id: string) { const { error } = await supabase.from('promo_codes').delete().eq('id', id); setMessage(error ? 'Promo kod o‘chirilmadi.' : 'Promo kod o‘chirildi.'); if (!error) void loadData(); }
  async function addKey(event: FormEvent) { event.preventDefault(); const generated = `MV-${crypto.randomUUID().slice(0, 4).toUpperCase()}-${crypto.randomUUID().slice(0, 4).toUpperCase()}-${crypto.randomUUID().slice(0, 4).toUpperCase()}`; const { error } = await supabase.from('activation_keys').insert({ key_value: generated, plan_name: keyPlan, duration_days: Number(keyDays) }); setMessage(error ? 'Kalit yaratilmadi.' : `Yangi kalit: ${generated}`); if (!error) void loadData(); }
  async function updatePlan(plan: Plan, field: 'price' | 'is_active', value: number | boolean) { const { error } = await supabase.from('plans').update({ [field]: value }).eq('id', plan.id); setMessage(error ? 'Tarifni saqlab bo‘lmadi.' : 'Tarif yangilandi.'); }

  if (profile?.role !== 'admin') return <section className="inner-page page-width"><div className="empty-access glass-card"><LockKeyhole size={38} /><h2>Admin panel yopiq</h2><p>Bu bo‘lim faqat tasdiqlangan admin uchun.</p></div></section>;
  const pendingOrders = orders.filter((order) => order.status === 'pending');
  return <section className="inner-page page-width admin-page"><div className="admin-head"><div><div className="eyebrow">CONTROL CENTER / ADMIN</div><h1>Boshqaruv paneli</h1><p>Buyurtma, mod, kalit, promo va bonuslarni bitta markazdan boshqaring.</p></div><div className="admin-live"><span /> LIVE SYSTEM</div></div><div className="admin-layout"><aside className="admin-sidebar glass-card"><button className={tab === 'overview' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('overview')}><LayoutDashboard size={17} /> Umumiy</button><button className={tab === 'orders' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('orders')}><CreditCard size={17} /> Buyurtmalar {pendingOrders.length > 0 && <b className="nav-count">{pendingOrders.length}</b>}</button><button className={tab === 'mods' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('mods')}><FileArchive size={17} /> Mod fayllari</button><button className={tab === 'keys' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('keys')}><KeyRound size={17} /> Kalitlar</button><button className={tab === 'promo' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('promo')}><Tag size={17} /> Promo kodlar</button><button className={tab === 'plans' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('plans')}><Package size={17} /> Tariflar</button><button className={tab === 'users' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('users')}><Users size={17} /> Foydalanuvchilar</button><button className={tab === 'bonus' ? 'admin-nav active' : 'admin-nav'} onClick={() => setTab('bonus')}><Gift size={17} /> Bonus tarixi</button></aside><div className="admin-content">{message && <div className="admin-message"><CheckCircle2 size={16} /> {message}<button onClick={() => setMessage('')}><X size={14} /></button></div>}{tab === 'overview' && <><div className="admin-stat-grid"><AdminStat icon={<Users />} label="Foydalanuvchilar" value={String(users.length)} delta="real vaqt" /><AdminStat icon={<CreditCard />} label="Kutilayotgan to‘lov" value={String(pendingOrders.length)} delta="tekshiruvda" /><AdminStat icon={<FileArchive />} label="Mod fayllari" value={String(assets.length)} delta="yuklangan" /><AdminStat icon={<Gift />} label="Bonus claimlar" value={String(bonusHistory.length)} delta="tarixda" /></div><div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">BOSHQARUV</span><h3>Tezkor amallar</h3></div><ShieldCheck size={19} /></div><div className="quick-actions"><button className="button button-primary" onClick={() => setTab('orders')}><CreditCard size={16} /> To‘lovlarni ko‘rish</button><button className="button button-outline" onClick={() => setTab('mods')}><Upload size={16} /> Mod yuklash</button><button className="button button-outline" onClick={() => setTab('keys')}><KeyRound size={16} /> Kalit yaratish</button></div></div></>}{tab === 'orders' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">PAYMENT QUEUE</span><h3>To‘lov so‘rovlari</h3></div><CreditCard size={19} /></div><div className="admin-toolbar"><select value={selectedAsset} onChange={(event) => setSelectedAsset(event.target.value)}><option value="">Modni tanlang</option>{assets.map((asset) => <option value={asset.id} key={asset.id}>{asset.name} v{asset.version}</option>)}</select><span>{pendingOrders.length} ta kutilmoqda</span></div><div className="admin-list">{orders.length === 0 ? <div className="empty-state"><CreditCard size={26} /><span>Hali buyurtmalar yo‘q</span></div> : orders.map((order) => <div className="admin-order-row" key={order.id}><div className="order-icon"><CreditCard size={15} /></div><div className="admin-order-info"><strong>{order.profile?.username || 'Foydalanuvchi'}</strong><span>{order.profile?.email || order.user_id}</span><small>{order.plan_name} • {formatPrice(order.price)} so‘m • {new Date(order.created_at).toLocaleString('uz-UZ')}</small></div><button className="button button-outline" disabled={!order.receipt_path} onClick={() => void openReceipt(order.receipt_path)}><Eye size={15} /> Chek</button><button className="button button-primary" disabled={busy || order.status !== 'pending'} onClick={() => void approveOrder(order.id)}>{order.status === 'paid' ? 'Tasdiqlangan' : 'Tasdiqlash'}</button></div>)}</div></div>}{tab === 'mods' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">DIGITAL DELIVERY</span><h3>Mod faylini yuklash</h3></div><FileArchive size={19} /></div><div className="asset-form"><input value={assetName} onChange={(event) => setAssetName(event.target.value)} placeholder="Mod nomi" /><input value={assetVersion} onChange={(event) => setAssetVersion(event.target.value)} placeholder="Versiya" /><label className="file-drop"><Upload size={18} /><span>Modni tanlang (.jar yoki .zip)<small>50 MB gacha</small></span><input type="file" accept=".jar,.zip,application/java-archive,application/zip" onChange={(event) => void uploadMod(event)} disabled={busy} /></label></div><div className="admin-list">{assets.map((asset) => <div className="admin-plan-row" key={asset.id}><div className="plan-mini-icon"><FileArchive size={16} /></div><div><strong>{asset.name}</strong><small>v{asset.version} • {(asset.file_size / 1024 / 1024).toFixed(1)} MB</small></div><span className="asset-active">{asset.is_active ? 'Faol' : 'Yopiq'}</span></div>)}</div></div>}{tab === 'keys' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">ACCESS CONTROL</span><h3>Aktivatsiya kalitlari</h3></div><KeyRound size={19} /></div><form className="key-generator" onSubmit={addKey}><select value={keyPlan} onChange={(event) => setKeyPlan(event.target.value)}><option>30 kunlik Visual</option><option>90 kunlik Visual</option><option>Lifetime Visual</option></select><input type="number" min="1" value={keyDays} onChange={(event) => setKeyDays(event.target.value)} /><button className="button button-primary"><Plus size={16} /> Kalit yaratish</button></form><div className="admin-list">{keys.map((key) => <div className="promo-row" key={key.id}><strong>{key.key_value}</strong><span>{key.plan_name}</span><small>{key.used_at ? 'Ishlatilgan' : 'Bo‘sh'}</small></div>)}</div></div>}{tab === 'promo' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">MARKETING</span><h3>Promo kodlar</h3></div><Tag size={19} /></div><form className="promo-form" onSubmit={addCode}><input value={newCode} onChange={(event) => setNewCode(event.target.value)} placeholder="WELCOME30" required /><input type="number" min="1" max="100" value={discount} onChange={(event) => setDiscount(event.target.value)} /><button className="button button-primary"><Plus size={16} /> Yaratish</button></form><div className="promo-list">{codes.map((code) => <div className="promo-row" key={code.id}><strong>{code.code}</strong><span>{code.discount_percent}% chegirma</span><small>{code.uses}/{code.max_uses}</small><button className="icon-button danger" onClick={() => void deleteCode(code.id)}><Trash2 size={15} /></button></div>)}</div></div>}{tab === 'plans' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">PRODUCT CONTROL</span><h3>Tariflar va narxlar</h3></div><Pencil size={19} /></div>{plans.map((plan) => <div className="admin-plan-row editable" key={plan.id}><div className="plan-mini-icon"><Sparkles size={16} /></div><div><strong>{plan.name}</strong><small>{plan.duration_days > 1000 ? 'Lifetime' : `${plan.duration_days} kun`} visual</small></div><input type="number" defaultValue={plan.price} onBlur={(event) => void updatePlan(plan, 'price', Number(event.target.value))} /><label className="toggle"><input type="checkbox" defaultChecked={plan.is_active} onChange={(event) => void updatePlan(plan, 'is_active', event.target.checked)} /><span /></label></div>)}</div>}{tab === 'users' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">CUSTOMERS</span><h3>Foydalanuvchilar</h3></div><Users size={19} /></div><div className="admin-list">{users.map((user) => <div className="admin-user-row" key={user.id}><div className="avatar">{user.username.slice(0, 1).toUpperCase()}</div><div><strong>{user.username}</strong><small>{user.email}</small></div><span className={user.role === 'admin' ? 'role-admin' : ''}>{user.role}</span><small>{new Date(user.created_at).toLocaleDateString('uz-UZ')}</small></div>)}</div></div>}{tab === 'bonus' && <div className="dashboard-card glass-card"><div className="card-heading"><div><span className="small-label">REWARD HISTORY</span><h3>Bonuslar tarixi</h3></div><History size={19} /></div><div className="admin-list">{bonusHistory.length === 0 ? <div className="empty-state"><Gift size={24} /><span>Hali bonus tarixi yo‘q</span></div> : bonusHistory.map((claim) => <div className="promo-row" key={claim.id}><strong>{claim.claimed_on}</strong><span>{claim.reward_type}</span><small>{claim.reward_value}</small></div>)}</div></div>}</div></div></section>;
}

function AdminStat({ icon, label, value, delta }: { icon: JSX.Element; label: string; value: string; delta: string }) { return <div className="admin-stat glass-card"><div className="stat-icon cyan">{icon}</div><span>{label}</span><strong>{value}</strong><small>{delta} <em>shu oy</em></small></div>; }
function Help() { return <section className="inner-page page-width help-page"><div className="inner-hero"><div className="eyebrow">SUPPORT CENTER</div><h1>Yordam kerakmi?</h1><p>MoneyVisuals bo‘yicha savollaringizga javob va tezkor aloqa.</p></div><div className="help-grid"><div className="help-card glass-card"><div className="help-icon"><CircleHelp /></div><h3>Aktivatsiya qanday ishlaydi?</h3><p>Tarifni tanlang, buyurtma yuboring va to‘lovdan keyin admin visualingizni hisobingizga biriktiradi. Siz kalit olgan bo‘lsangiz, uni shaxsiy kabinetda kiritishingiz mumkin.</p><button className="text-button">Ko‘proq o‘qish <ArrowRight size={16} /></button></div><div className="help-card glass-card"><div className="help-icon emerald"><ExternalLink /></div><h3>Biz bilan bog‘laning</h3><p>Buyurtma, to‘lov yoki texnik savol bo‘lsa, Discord orqali yozing. Yordam jamoasi sizga javob beradi.</p><a className="button button-outline" href="https://discord.com" target="_blank" rel="noreferrer">Discord: MoneySupport <ExternalLink size={15} /></a></div><div className="faq-card glass-card"><div className="card-heading"><div><span className="small-label">FAQ</span><h3>Ko‘p so‘raladigan savollar</h3></div><BookOpen size={19} /></div>{['Visual qachon faollashadi?', 'HWID nima uchun kerak?', 'Kalitni qayta ishlatish mumkinmi?'].map((question) => <button className="faq-row" key={question}><span>{question}</span><ChevronRight size={16} /></button>)}</div></div></section>; }

export default App;
