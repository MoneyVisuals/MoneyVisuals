/*
# Add secure promo checkout

1. Modified Tables
- `orders.promo_code`: the applied code, when one was used.
- `orders.discount_percent`: the server-calculated discount.
- `orders.final_price`: the server-calculated amount after discount.

2. Security
- Adds a server-side order function that reads the active plan price from the database.
- Promo codes are checked and usage is incremented in one atomic update.
- Direct client inserts into `orders` are revoked so users cannot forge prices or discounts.
- Only signed-in users can create their own checkout order through the function.

3. Important Notes
- An invalid, inactive, or exhausted code is rejected with a generic error.
- Empty promo codes are treated as no discount.
*/

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS promo_code text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS discount_percent integer NOT NULL DEFAULT 0 CHECK (discount_percent BETWEEN 0 AND 100);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS final_price integer;

REVOKE INSERT ON public.orders FROM authenticated;

CREATE OR REPLACE FUNCTION public.create_order_with_promo(p_plan_id uuid, p_receipt_path text, p_promo_code text DEFAULT NULL)
RETURNS public.orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  selected_plan public.plans;
  selected_promo public.promo_codes;
  created_order public.orders;
  normalized_code text := NULLIF(upper(trim(COALESCE(p_promo_code, ''))), '');
  calculated_discount integer := 0;
  calculated_price integer;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF p_receipt_path IS NULL OR split_part(p_receipt_path, '/', 1) <> auth.uid()::text THEN RAISE EXCEPTION 'Invalid receipt'; END IF;
  SELECT * INTO selected_plan FROM public.plans WHERE id = p_plan_id AND is_active = true;
  IF selected_plan.id IS NULL THEN RAISE EXCEPTION 'Plan unavailable'; END IF;

  IF normalized_code IS NOT NULL THEN
    UPDATE public.promo_codes
    SET uses = uses + 1
    WHERE upper(code) = normalized_code AND is_active = true AND uses < max_uses
    RETURNING * INTO selected_promo;
    IF selected_promo.id IS NULL THEN RAISE EXCEPTION 'Promo unavailable'; END IF;
    calculated_discount := selected_promo.discount_percent;
  END IF;

  calculated_price := round(selected_plan.price * (100 - calculated_discount) / 100.0);
  INSERT INTO public.orders (user_id, plan_id, plan_name, price, final_price, discount_percent, promo_code, receipt_path, status)
  VALUES (auth.uid(), selected_plan.id, selected_plan.name, selected_plan.price, calculated_price, calculated_discount, normalized_code, p_receipt_path, 'pending')
  RETURNING * INTO created_order;
  RETURN created_order;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.create_order_with_promo(uuid, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION public.create_order_with_promo(uuid, text, text) TO authenticated;
