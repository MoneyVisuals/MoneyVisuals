/*
# Add protected payment receipt uploads

1. Modified Tables
- `orders.receipt_path`: stores the private storage path of the payment receipt attached to an order.

2. Storage
- Creates the private `payment-receipts` bucket for uploaded receipt images.
- Files are stored inside a folder named with the signed-in user's ID.

3. Security
- Signed-in users can upload only into their own folder.
- Signed-in users can read their own receipt files.
- Admins can read, update, and delete receipt files for payment verification.
- Upload policies are separate from database row policies.

4. Important Notes
- The bucket is private; receipts are not exposed through public URLs.
- The application enforces image-only uploads and a 5 MB limit before upload, while storage policies enforce ownership.
*/

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS receipt_path text;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('payment-receipts', 'payment-receipts', false, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp']::text[])
ON CONFLICT (id) DO UPDATE SET public = false, file_size_limit = 5242880, allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp']::text[];

DROP POLICY IF EXISTS "receipt_insert_own_folder" ON storage.objects;
CREATE POLICY "receipt_insert_own_folder" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'payment-receipts' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "receipt_select_own_or_admin" ON storage.objects;
CREATE POLICY "receipt_select_own_or_admin" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'payment-receipts' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.is_admin()));

DROP POLICY IF EXISTS "receipt_update_own_or_admin" ON storage.objects;
CREATE POLICY "receipt_update_own_or_admin" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'payment-receipts' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.is_admin()))
WITH CHECK (bucket_id = 'payment-receipts' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.is_admin()));

DROP POLICY IF EXISTS "receipt_delete_own_or_admin" ON storage.objects;
CREATE POLICY "receipt_delete_own_or_admin" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'payment-receipts' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.is_admin()));
