/*
# Create MoneyVisuals account, catalog, and order data

1. New Tables
- `profiles`: username, email, and server-controlled role for each signed-in account.
- `plans`: public visual subscription catalog with name, duration, price, and accent.
- `orders`: a private record of each user's chosen plan and manual-payment status.
- `promo_codes`: admin-managed discount codes and redemption counts.
- `activation_keys`: admin-managed single-use subscription keys.

2. Security
- RLS is enabled on every new table.
- Public visitors can read active plans only.
- Signed-in users can read and update only their own profile and orders.
- Admin-only operations are protected by a server-side role check.
- Activation keys are claimed atomically through a security-definer function.

3. Important Notes
- The first registered account is assigned the admin role by the profile trigger.
- User-controlled profile fields are limited to username.
- Payment card details are intentionally not stored in the database; the app presents the merchant-provided manual payment instruction in the checkout screen.
*/

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  hwid text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_key ON public.profiles (lower(username));

CREATE TABLE IF NOT EXISTS public.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  duration_days integer NOT NULL CHECK (duration_days > 0),
  price integer NOT NULL CHECK (price >= 0),
  description text NOT NULL DEFAULT '',
  accent text NOT NULL DEFAULT 'cyan',
  is_featured boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id uuid REFERENCES public.plans(id) ON DELETE SET NULL,
  plan_name text NOT NULL,
  price integer NOT NULL CHECK (price >= 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'rejected')),
  payment_method text NOT NULL DEFAULT 'manual_card',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.promo_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  discount_percent integer NOT NULL CHECK (discount_percent BETWEEN 1 AND 100),
  max_uses integer NOT NULL DEFAULT 100 CHECK (max_uses > 0),
  uses integer NOT NULL DEFAULT 0 CHECK (uses >= 0),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.activation_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_value text UNIQUE NOT NULL,
  plan_name text NOT NULL,
  duration_days integer NOT NULL CHECK (duration_days > 0),
  used_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promo_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activation_keys ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin');
$$;

REVOKE EXECUTE ON FUNCTION public.is_admin() FROM anon;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

DROP POLICY IF EXISTS "profiles_select_own_or_admin" ON public.profiles;
CREATE POLICY "profiles_select_own_or_admin" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.is_admin());
DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
DROP POLICY IF EXISTS "profiles_update_own_username" ON public.profiles;
CREATE POLICY "profiles_update_own_username" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
DROP POLICY IF EXISTS "profiles_delete_own" ON public.profiles;
CREATE POLICY "profiles_delete_own" ON public.profiles FOR DELETE TO authenticated USING (id = auth.uid());

DROP POLICY IF EXISTS "plans_select_active" ON public.plans;
CREATE POLICY "plans_select_active" ON public.plans FOR SELECT TO anon, authenticated USING (is_active = true OR public.is_admin());
DROP POLICY IF EXISTS "plans_insert_admin" ON public.plans;
CREATE POLICY "plans_insert_admin" ON public.plans FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "plans_update_admin" ON public.plans;
CREATE POLICY "plans_update_admin" ON public.plans FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "plans_delete_admin" ON public.plans;
CREATE POLICY "plans_delete_admin" ON public.plans FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "orders_select_own_or_admin" ON public.orders;
CREATE POLICY "orders_select_own_or_admin" ON public.orders FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_admin());
DROP POLICY IF EXISTS "orders_insert_own" ON public.orders;
CREATE POLICY "orders_insert_own" ON public.orders FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "orders_update_admin" ON public.orders;
CREATE POLICY "orders_update_admin" ON public.orders FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "orders_delete_admin" ON public.orders;
CREATE POLICY "orders_delete_admin" ON public.orders FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "promo_select_admin" ON public.promo_codes;
CREATE POLICY "promo_select_admin" ON public.promo_codes FOR SELECT TO authenticated USING (public.is_admin());
DROP POLICY IF EXISTS "promo_insert_admin" ON public.promo_codes;
CREATE POLICY "promo_insert_admin" ON public.promo_codes FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "promo_update_admin" ON public.promo_codes;
CREATE POLICY "promo_update_admin" ON public.promo_codes FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "promo_delete_admin" ON public.promo_codes;
CREATE POLICY "promo_delete_admin" ON public.promo_codes FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "keys_select_admin" ON public.activation_keys;
CREATE POLICY "keys_select_admin" ON public.activation_keys FOR SELECT TO authenticated USING (public.is_admin());
DROP POLICY IF EXISTS "keys_insert_admin" ON public.activation_keys;
CREATE POLICY "keys_insert_admin" ON public.activation_keys FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "keys_update_admin" ON public.activation_keys;
CREATE POLICY "keys_update_admin" ON public.activation_keys FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "keys_delete_admin" ON public.activation_keys;
CREATE POLICY "keys_delete_admin" ON public.activation_keys FOR DELETE TO authenticated USING (public.is_admin());

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  account_count integer;
  requested_username text;
BEGIN
  SELECT count(*) INTO account_count FROM public.profiles;
  requested_username := COALESCE(NULLIF(trim(NEW.raw_user_meta_data ->> 'username'), ''), split_part(NEW.email, '@', 1));
  INSERT INTO public.profiles (id, username, email, role)
  VALUES (NEW.id, requested_username, NEW.email, CASE WHEN account_count = 0 THEN 'admin' ELSE 'user' END);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.redeem_activation_key(p_key text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  claimed public.activation_keys;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  UPDATE public.activation_keys
  SET used_by = auth.uid(), used_at = now()
  WHERE upper(key_value) = upper(trim(p_key)) AND used_at IS NULL
  RETURNING * INTO claimed;
  IF claimed.id IS NULL THEN RAISE EXCEPTION 'Key unavailable'; END IF;
  RETURN jsonb_build_object('plan_name', claimed.plan_name, 'duration_days', claimed.duration_days);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.redeem_activation_key(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.redeem_activation_key(text) TO authenticated;

INSERT INTO public.plans (slug, name, duration_days, price, description, accent, is_featured)
VALUES
  ('starter-30', 'Starter Visual', 30, 12000, 'Asosiy vizual paket va tezkor aktivatsiya.', 'cyan', false),
  ('pro-90', 'Pro Visual', 90, 30000, 'Uzoq muddatli foydalanish va premium effektlar.', 'emerald', true),
  ('forever', 'Lifetime Visual', 3650, 50000, 'Bir marta to‘lang, uzoq muddat foydalaning.', 'gold', false)
ON CONFLICT (slug) DO UPDATE SET name = excluded.name, duration_days = excluded.duration_days, price = excluded.price, description = excluded.description, accent = excluded.accent, is_featured = excluded.is_featured;
