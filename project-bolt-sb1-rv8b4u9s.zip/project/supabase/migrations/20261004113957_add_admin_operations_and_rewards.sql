/*
# Add admin operations, digital mod delivery, and daily rewards

1. New Tables
- `mod_assets`: admin-uploaded mod files and their public product metadata.
- `user_entitlements`: subscriptions and mod access granted to a user after an approved payment or key.
- `daily_bonus_claims`: one claim per user per calendar day with the reward and claim history.

2. Modified Tables
- `orders`: adds `asset_id` so an approved order points to the mod delivered to the buyer.

3. Storage
- Creates the private `mod-files` bucket for admin-only uploads and entitled-user downloads.

4. Security
- All new tables use RLS with owner-scoped user access and admin-only management.
- Receipt and mod storage access is private.
- Order approval and daily bonus claiming are server-side functions.
- A buyer can download only a mod attached to one of their active entitlements.

5. Important Notes
- Admin approval is atomic: the order is marked paid and access is granted together.
- Daily rewards are protected by a unique user/date constraint and cannot be claimed twice on the same day.
*/

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS asset_id uuid;

CREATE TABLE IF NOT EXISTS public.mod_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  version text NOT NULL DEFAULT '1.0.0',
  file_path text NOT NULL,
  file_size bigint NOT NULL DEFAULT 0 CHECK (file_size >= 0),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.user_entitlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  asset_id uuid NOT NULL REFERENCES public.mod_assets(id) ON DELETE RESTRICT,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  plan_name text NOT NULL,
  starts_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'expired', 'revoked')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.daily_bonus_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  reward_type text NOT NULL CHECK (reward_type IN ('promo', 'balance', 'key', 'cosmetic')),
  reward_value text NOT NULL,
  claimed_on date NOT NULL DEFAULT current_date,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, claimed_on)
);

ALTER TABLE public.mod_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_entitlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_bonus_claims ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_asset_id_fkey;
ALTER TABLE public.orders ADD CONSTRAINT orders_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.mod_assets(id) ON DELETE SET NULL;

DROP POLICY IF EXISTS "assets_select_active_or_admin" ON public.mod_assets;
CREATE POLICY "assets_select_active_or_admin" ON public.mod_assets FOR SELECT TO authenticated USING (is_active OR public.is_admin());
DROP POLICY IF EXISTS "assets_insert_admin" ON public.mod_assets;
CREATE POLICY "assets_insert_admin" ON public.mod_assets FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "assets_update_admin" ON public.mod_assets;
CREATE POLICY "assets_update_admin" ON public.mod_assets FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "assets_delete_admin" ON public.mod_assets;
CREATE POLICY "assets_delete_admin" ON public.mod_assets FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "entitlements_select_own_or_admin" ON public.user_entitlements;
CREATE POLICY "entitlements_select_own_or_admin" ON public.user_entitlements FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_admin());
DROP POLICY IF EXISTS "entitlements_insert_admin" ON public.user_entitlements;
CREATE POLICY "entitlements_insert_admin" ON public.user_entitlements FOR INSERT TO authenticated WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "entitlements_update_admin" ON public.user_entitlements;
CREATE POLICY "entitlements_update_admin" ON public.user_entitlements FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "entitlements_delete_admin" ON public.user_entitlements;
CREATE POLICY "entitlements_delete_admin" ON public.user_entitlements FOR DELETE TO authenticated USING (public.is_admin());

DROP POLICY IF EXISTS "bonus_select_own_or_admin" ON public.daily_bonus_claims;
CREATE POLICY "bonus_select_own_or_admin" ON public.daily_bonus_claims FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_admin());
DROP POLICY IF EXISTS "bonus_insert_own" ON public.daily_bonus_claims;
CREATE POLICY "bonus_insert_own" ON public.daily_bonus_claims FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "bonus_update_admin" ON public.daily_bonus_claims;
CREATE POLICY "bonus_update_admin" ON public.daily_bonus_claims FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS "bonus_delete_admin" ON public.daily_bonus_claims;
CREATE POLICY "bonus_delete_admin" ON public.daily_bonus_claims FOR DELETE TO authenticated USING (public.is_admin());

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('mod-files', 'mod-files', false, 52428800, ARRAY['application/zip', 'application/java-archive', 'application/octet-stream']::text[])
ON CONFLICT (id) DO UPDATE SET public = false, file_size_limit = 52428800, allowed_mime_types = ARRAY['application/zip', 'application/java-archive', 'application/octet-stream']::text[];

DROP POLICY IF EXISTS "mod_insert_admin" ON storage.objects;
CREATE POLICY "mod_insert_admin" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'mod-files' AND public.is_admin());
DROP POLICY IF EXISTS "mod_select_admin_or_entitled" ON storage.objects;
CREATE POLICY "mod_select_admin_or_entitled" ON storage.objects FOR SELECT TO authenticated USING (
  bucket_id = 'mod-files' AND (public.is_admin() OR EXISTS (
    SELECT 1 FROM public.user_entitlements ue
    JOIN public.mod_assets ma ON ma.id = ue.asset_id
    WHERE ue.user_id = auth.uid() AND ue.status = 'active' AND ma.file_path = storage.objects.name
  ))
);
DROP POLICY IF EXISTS "mod_update_admin" ON storage.objects;
CREATE POLICY "mod_update_admin" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'mod-files' AND public.is_admin()) WITH CHECK (bucket_id = 'mod-files' AND public.is_admin());
DROP POLICY IF EXISTS "mod_delete_admin" ON storage.objects;
CREATE POLICY "mod_delete_admin" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'mod-files' AND public.is_admin());

CREATE OR REPLACE FUNCTION public.approve_order(p_order_id uuid, p_asset_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_order public.orders;
  target_asset public.mod_assets;
BEGIN
  IF NOT public.is_admin() THEN RAISE EXCEPTION 'Not authorized'; END IF;
  SELECT * INTO target_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
  SELECT * INTO target_asset FROM public.mod_assets WHERE id = p_asset_id AND is_active = true;
  IF target_order.id IS NULL OR target_asset.id IS NULL THEN RAISE EXCEPTION 'Invalid order or asset'; END IF;
  UPDATE public.orders SET status = 'paid', asset_id = target_asset.id WHERE id = target_order.id;
  INSERT INTO public.user_entitlements (user_id, asset_id, order_id, plan_name, starts_at, expires_at, status)
  SELECT target_order.user_id, target_asset.id, target_order.id, target_order.plan_name, now(),
    CASE WHEN p.duration_days > 1000 THEN NULL ELSE now() + make_interval(days => p.duration_days) END, 'active'
  FROM public.plans p WHERE p.name = target_order.plan_name
  ON CONFLICT DO NOTHING;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.approve_order(uuid, uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.approve_order(uuid, uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.claim_daily_bonus()
RETURNS public.daily_bonus_claims
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  claimed public.daily_bonus_claims;
  reward_types text[] := ARRAY['promo', 'balance', 'cosmetic', 'key'];
  selected_type text;
  selected_value text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  selected_type := reward_types[1 + floor(random() * array_length(reward_types, 1))::int];
  selected_value := CASE selected_type WHEN 'promo' THEN '10% chegirma' WHEN 'balance' THEN '1,000 so‘m bonus' WHEN 'cosmetic' THEN 'Rare cosmetic' ELSE '1 kunlik bonus kalit' END;
  INSERT INTO public.daily_bonus_claims (user_id, reward_type, reward_value)
  VALUES (auth.uid(), selected_type, selected_value)
  ON CONFLICT (user_id, claimed_on) DO NOTHING
  RETURNING * INTO claimed;
  IF claimed.id IS NULL THEN RAISE EXCEPTION 'Already claimed today'; END IF;
  RETURN claimed;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.claim_daily_bonus() FROM anon;
GRANT EXECUTE ON FUNCTION public.claim_daily_bonus() TO authenticated;
